package com.imanalyzer.peridotlabeltester

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val sppUuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null

    private lateinit var status: TextView
    private lateinit var offsetInput: EditText
    private lateinit var rawInput: EditText

    private val labelWidthMm = 45.0
    private val labelHeightMm = 13.9
    private val gapMm = 3.0
    private val dotsPerMm = 8.0   // 203 dpi ≈ 8 dots/mm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBtPermissionIfNeeded()
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 40)
        }

        fun title(text: String, size: Float) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 8, 0, 8)
        }

        root.addView(title("Peridot Label Tester", 24f))
        root.addView(title("45 × 13.9 mm  •  GAP 3 mm", 16f))

        status = TextView(this).apply {
            text = "Not connected"
            textSize = 15f
            setPadding(0, 10, 0, 18)
        }
        root.addView(status)

        root.addView(button("CONNECT BLUETOOTH") { chooseBondedPrinter() })
        root.addView(button("DISCONNECT") { disconnectPrinter() })

        root.addView(title("Gap / Home Test", 19f))
        root.addView(button("SET 45×13.9 + GAP 3") {
            sendTspl("""
                SIZE 45 mm,13.9 mm
                GAP 3 mm,0 mm
            """.trimIndent())
        })
        root.addView(button("CALIBRATE GAP (GAPDETECT)") {
            sendTspl("""
                SIZE 45 mm,13.9 mm
                GAP 3 mm,0 mm
                GAPDETECT
            """.trimIndent())
        })
        root.addView(button("HOME TO LABEL ORIGIN") {
            sendTspl("""
                SIZE 45 mm,13.9 mm
                GAP 3 mm,0 mm
                HOME
            """.trimIndent())
        })
        root.addView(button("FEED EXACTLY 1 LABEL (FORMFEED)") {
            sendTspl("""
                SIZE 45 mm,13.9 mm
                GAP 3 mm,0 mm
                FORMFEED
            """.trimIndent())
        })

        root.addView(title("Manual Paper Movement", 19f))
        root.addView(row(
            button("FWD 1 mm") { feedMm(1.0) },
            button("FWD 2 mm") { feedMm(2.0) },
            button("FWD 5 mm") { feedMm(5.0) }
        ))
        root.addView(row(
            button("BACK 1 mm") { backfeedMm(1.0) },
            button("BACK 2 mm") { backfeedMm(2.0) },
            button("BACK 5 mm") { backfeedMm(5.0) }
        ))
        root.addView(button("BACKUP 5 mm (older TSPL test)") {
            val dots = (5.0 * dotsPerMm).roundToInt()
            sendTspl("BACKUP $dots")
        })

        root.addView(title("Print Tests", 19f))
        root.addView(button("PRINT TEST — DIRECTION 0") { printTest(0, null) })
        root.addView(button("PRINT TEST — DIRECTION 1") { printTest(1, null) })

        val offsetLabel = TextView(this).apply {
            text = "Cutter / tear OFFSET in mm (try 0, then 2, 4, 6...)"
            textSize = 15f
            setPadding(0, 12, 0, 4)
        }
        root.addView(offsetLabel)

        offsetInput = EditText(this).apply {
            setText("0")
            hint = "Offset mm"
            inputType = InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        root.addView(offsetInput)

        root.addView(button("APPLY OFFSET ONLY") {
            val v = offsetInput.text.toString().toDoubleOrNull() ?: 0.0
            sendTspl("OFFSET ${formatMm(v)} mm")
        })
        root.addView(button("PRINT + OFFSET") {
            val v = offsetInput.text.toString().toDoubleOrNull() ?: 0.0
            printTest(0, v)
        })

        root.addView(title("Raw TSPL", 19f))
        rawInput = EditText(this).apply {
            minLines = 6
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(
                "SIZE 45 mm,13.9 mm\n" +
                "GAP 3 mm,0 mm\n" +
                "DIRECTION 0\n" +
                "CLS\n" +
                "TEXT 8,8,\"0\",0,1,1,\"RAW TEST\"\n" +
                "PRINT 1,1"
            )
        }
        root.addView(rawInput)
        root.addView(button("SEND RAW TSPL") {
            sendTspl(rawInput.text.toString())
        })

        root.addView(title(
            "Safety: use small backfeed/offset values first. " +
            "If the paper wrinkles, jams, or pulls hard, stop immediately.",
            13f
        ))

        scroll.addView(root)
        return scroll
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            minHeight = 56
            setOnClickListener { onClick() }
        }
    }

    private fun row(vararg views: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { v ->
                addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
        }
    }

    private fun requestBtPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1001)
        }
    }

    private fun chooseBondedPrinter() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestBtPermissionIfNeeded()
            toast("Allow Nearby devices permission, then tap Connect again.")
            return
        }

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            toast("Bluetooth is not supported on this phone.")
            return
        }
        if (!adapter.isEnabled) {
            toast("Turn Bluetooth ON first.")
            return
        }

        val devices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
        if (devices.isEmpty()) {
            toast("No paired devices. Pair the Peridot printer in Android Bluetooth settings first.")
            return
        }

        val names = devices.map { "${it.name ?: "Unknown"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose paired printer")
            .setItems(names) { _, which -> connectTo(devices[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun connectTo(device: BluetoothDevice) {
        status.text = "Connecting to ${device.name ?: device.address}..."
        thread {
            try {
                disconnectPrinter()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                output = s.outputStream
                runOnUiThread {
                    status.text = "Connected: ${device.name ?: device.address}"
                    toast("Printer connected")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Connection failed: ${e.message}"
                    toast("Connection failed")
                }
            }
        }
    }

    private fun disconnectPrinter() {
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        output = null
        socket = null
        if (::status.isInitialized) runOnUiThread { status.text = "Not connected" }
    }

    private fun sendTspl(command: String) {
        val clean = command.trim().replace("\n", "\r\n") + "\r\n"
        val out = output
        if (out == null) {
            toast("Connect printer first.")
            return
        }
        status.text = "Sending: ${clean.lines().firstOrNull() ?: ""}"
        thread {
            try {
                out.write(clean.toByteArray(Charsets.US_ASCII))
                out.flush()
                runOnUiThread { status.text = "Sent successfully" }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Send failed: ${e.message}"
                    toast("Send failed")
                }
            }
        }
    }

    private fun feedMm(mm: Double) {
        val dots = (mm * dotsPerMm).roundToInt().coerceAtLeast(1)
        sendTspl("FEED $dots")
    }

    private fun backfeedMm(mm: Double) {
        val dots = (mm * dotsPerMm).roundToInt().coerceAtLeast(1)
        sendTspl("BACKFEED $dots")
    }

    private fun printTest(direction: Int, offsetMm: Double?) {
        val widthDots = (labelWidthMm * dotsPerMm).roundToInt()
        val heightDots = (labelHeightMm * dotsPerMm).roundToInt()
        val right = widthDots - 4
        val bottom = heightDots - 4

        val offsetLine = if (offsetMm != null) "OFFSET ${formatMm(offsetMm)} mm\n" else ""

        val cmd = """
            SIZE 45 mm,13.9 mm
            GAP 3 mm,0 mm
            ${offsetLine}DIRECTION $direction
            REFERENCE 0,0
            CLS
            BOX 2,2,$right,$bottom,1
            TEXT 8,8,"0",0,1,1,"START"
            TEXT 100,8,"0",0,1,1,"PERIDOT TEST"
            TEXT 8,48,"0",0,1,1,"45x13.9 GAP3"
            TEXT 285,82,"0",0,1,1,"END"
            PRINT 1,1
        """.trimIndent()

        sendTspl(cmd)
    }

    private fun formatMm(v: Double): String =
        if (v % 1.0 == 0.0) v.toInt().toString() else "%.1f".format(java.util.Locale.US, v)

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    override fun onDestroy() {
        disconnectPrinter()
        super.onDestroy()
    }
}
